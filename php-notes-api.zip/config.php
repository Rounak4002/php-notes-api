<?php
return ['db'=>['host'=>'127.0.0.1','dbname'=>'notes_api','user'=>'root','pass'=>'','charset'=>'utf8mb4']];